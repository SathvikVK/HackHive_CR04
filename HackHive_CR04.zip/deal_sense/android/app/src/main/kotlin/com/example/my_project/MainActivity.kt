package com.hackhive.dealsense

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
